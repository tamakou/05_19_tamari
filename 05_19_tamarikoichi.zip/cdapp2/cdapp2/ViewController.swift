//
//  ViewController.swift
//  cdapp2
//
//  Created by 玉利恒一 on 2019/01/10.
//  Copyright © 2019 玉利恒一. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    var timer : Timer?
    var count = 0
    let settingKey = "timer_value"

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let settings = UserDefaults.standard
        settings.register(defaults: [settingKey:180.0])
    }


    @IBOutlet weak var timelabel: UILabel!
    
    @IBAction func settingButton(_ sender: Any) {
        if let nowTimer = timer{
            
            if nowTimer.isValid == true{
                nowTimer.invalidate()
            }
        }
        
        performSegue(withIdentifier: "goSetting", sender: nil)
    }
    
    let gokuPath =
        Bundle.main.bundleURL.appendingPathComponent("Goku.mp3")
    
    var gokuPlayer = AVAudioPlayer()
    
    @IBAction func startButton(_ sender: Any) {
        
        do {
            //gokuのプレイヤーに音源ファイル名を指定
            gokuPlayer = try AVAudioPlayer(contentsOf: gokuPath, fileTypeHint: nil)
            
            //gokuの音源再生
            gokuPlayer.play()
        } catch{
            print("元気玉でエラーが発生致しました！")
        }
        
        if let nowTimer = timer{
            
            if nowTimer.isValid == true{
                
                return
            }
        }
        
        timer = Timer.scheduledTimer(timeInterval: 1.0,
                                     target: self,
                                     selector: #selector(self.timerInterrupt(_:)),
                                     userInfo: nil,
                                     repeats: true)
        
    }
    
    
    @IBAction func stopButton(_ sender: Any) {
        
        if let nowTimer = timer{
            if nowTimer.isValid == true{
                nowTimer.invalidate()
            }
        }
    }
    
    func displayUpdate() -> Int{
        let settings = UserDefaults.standard
        let timerValue = settings.integer(forKey: settingKey)
        let remainCount = timerValue - count
        timelabel.text = "\(remainCount)"
        
        return remainCount
    }
    
    @objc func timerInterrupt(_ timer:Timer){
        count += 1
        
        if displayUpdate() <= 0 {
            
            count = 0
            
            timer.invalidate()
            
            let alertController = UIAlertController(title: "完成！！", message: "美味しいカップラーメンができました。", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "いただきます"
                , style: .default, handler: nil)
            
            alertController.addAction(defaultAction)
            
            present(alertController, animated: true, completion: nil)
        }
    }
    
//    画面切り替え
    override func viewDidAppear(_ animated: Bool) {
        count = 0
        
        _ = displayUpdate()
    }
    
}

